package com.example.mcptiers;

import net.minecraft.class_2561;

/**
 * Duck interface mixed into EntityRenderState so the tier text found while the render
 * state is updated can be read again when the name tag is drawn.
 * Lives outside the mixin package on purpose (mixin packages cannot be referenced directly).
 */
public interface TierHolder {
    class_2561 mcpvp$getTier();

    void mcpvp$setTier(class_2561 tier);

    boolean mcpvp$isDrawn();

    void mcpvp$setDrawn(boolean drawn);
}
