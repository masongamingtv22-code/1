package com.example.mcptiers.mixin;

import com.example.mcptiers.TierHolder;
import net.minecraft.class_10017;
import net.minecraft.class_2561;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(class_10017.class)
public abstract class EntityRenderStateMixin implements TierHolder {
    @Unique
    private class_2561 mcpvp$tier;
    @Unique
    private boolean mcpvp$drawn;

    @Override
    public class_2561 mcpvp$getTier() {
        return mcpvp$tier;
    }

    @Override
    public void mcpvp$setTier(class_2561 tier) {
        this.mcpvp$tier = tier;
    }

    @Override
    public boolean mcpvp$isDrawn() {
        return mcpvp$drawn;
    }

    @Override
    public void mcpvp$setDrawn(boolean drawn) {
        this.mcpvp$drawn = drawn;
    }
}
