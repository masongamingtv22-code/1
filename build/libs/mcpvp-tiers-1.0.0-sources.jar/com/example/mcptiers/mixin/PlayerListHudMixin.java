package com.example.mcptiers.mixin;

import com.example.mcptiers.TierLookup;
import net.minecraft.class_2561;
import net.minecraft.class_355;
import net.minecraft.class_640;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_355.class)
public abstract class PlayerListHudMixin {
    @Inject(method = "getPlayerName", at = @At("RETURN"), cancellable = true)
    private void mcpvp$appendTier(class_640 entry, CallbackInfoReturnable<class_2561> cir) {
        class_2561 name = cir.getReturnValue();
        if (name == null) return;
        String player = TierLookup.resolveName(entry.method_2966().name(), name);
        class_2561 tier = TierLookup.suffix(player);
        if (tier != null && !tier.getString().isEmpty()) {
            TierLookup.debug("tab list: adding tier to " + player + " -> " + tier.getString().trim());
            cir.setReturnValue(name.method_27661().method_10852(tier));
        }
    }
}
