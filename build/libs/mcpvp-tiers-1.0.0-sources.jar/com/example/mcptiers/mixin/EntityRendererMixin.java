package com.example.mcptiers.mixin;

import com.example.mcptiers.TierHolder;
import com.example.mcptiers.TierLookup;
import net.minecraft.class_10017;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_4587;
import net.minecraft.class_897;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Draws the tier on its own line directly above the player's name tag.
 * Uses the same label queue as the vanilla name tag, so it billboards, fades,
 * and hides exactly like the name does.
 */
@Mixin(class_897.class)
public abstract class EntityRendererMixin {
    /** One text line is 9px tall; negative y moves the label up. */
    private static final int LINE_UP = -10;

    @Inject(method = "updateRenderState", at = @At("RETURN"))
    private void mcpvp$captureTier(class_1297 entity, class_10017 state, float tickProgress, CallbackInfo ci) {
        TierHolder holder = (TierHolder) (Object) state;
        holder.mcpvp$setDrawn(false);
        class_2561 tier = null;
        if (entity instanceof class_1657 player) {
            tier = TierLookup.tag(player.method_7334().name());
        }
        holder.mcpvp$setTier(tier);
    }

    @Inject(method = "renderLabelIfPresent", at = @At("HEAD"))
    private void mcpvp$renderTierAboveName(class_10017 state, class_4587 matrices, class_11659 queue,
                                           class_12075 cameraState, CallbackInfo ci) {
        TierHolder holder = (TierHolder) (Object) state;
        class_2561 tier = holder.mcpvp$getTier();
        // Only once per state per frame, and only when vanilla is drawing a name tag.
        if (tier == null || holder.mcpvp$isDrawn() || state.field_53338 == null || state.field_53337 == null) return;
        holder.mcpvp$setDrawn(true);
        TierLookup.debug("name tag: drawing " + tier.getString() + " above " + state.field_53337.getString());
        int y = "deadmau5".equals(state.field_53337.getString()) ? LINE_UP * 2 : LINE_UP;
        queue.method_73482(matrices, state.field_53338, y, tier, !state.field_53334, state.field_61820,
                state.field_53332, cameraState);
    }
}
