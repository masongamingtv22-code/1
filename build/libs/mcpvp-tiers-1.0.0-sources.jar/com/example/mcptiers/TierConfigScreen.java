package com.example.mcptiers;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public final class TierConfigScreen extends class_437 {
    private static final String[] OPTIONS = TierLookup.getOptions();
    private final class_437 parent;
    private int selected;

    public TierConfigScreen(class_437 parent) {
        super(class_2561.method_43470("MCPVP Tiers Settings"));
        this.parent = parent;
        String current = TierLookup.getConfiguredTier();
        for (int i = 0; i < OPTIONS.length; i++) {
            if (OPTIONS[i].equalsIgnoreCase(current)) {
                selected = i;
                break;
            }
        }
    }

    @Override
    protected void method_25426() {
        method_37063(class_4185.method_46430(optionLabel(), button -> {
            selected = (selected + 1) % OPTIONS.length;
            // Saved right away, so the choice sticks even if the screen is closed with Esc.
            TierLookup.setConfiguredTier(OPTIONS[selected]);
            button.method_25355(optionLabel());
        }).method_46434(field_22789 / 2 - 100, field_22790 / 2 - 10, 200, 20).method_46431());

        method_37063(class_4185.method_46430(class_2561.method_43470("Done"), button -> method_25419())
                .method_46434(field_22789 / 2 - 50, field_22790 / 2 + 20, 100, 20).method_46431());
    }

    private class_2561 optionLabel() {
        String value = OPTIONS[selected];
        String display = value.equals("highest") ? "Highest" : value.equals("overall") ? "Overall" : value;
        return class_2561.method_43470("Tier to show: " + display);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        context.method_27534(field_22793,
                class_2561.method_43470("Choose which tier shows above name tags and in the tab list"),
                field_22789 / 2, field_22790 / 2 - 35, 0xFFFFFFFF);
    }

    @Override
    public void method_25419() {
        if (field_22787 != null) field_22787.method_1507(parent);
    }
}
